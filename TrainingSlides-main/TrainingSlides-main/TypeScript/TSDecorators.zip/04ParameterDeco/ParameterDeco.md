# Parameter Decorators
A Parameter Decorator is is used to decorate a parameter of a class method or a class constructor.


The parameter decorator receives three arguments.

- The prototype of the class for an instance member OR the constructor function of the class for a static member.
- The name of the method that uses the parameter.
- The index of the parameter in the function’s parameter list.